export default function FalciPaneli() {
  return <div style={{ padding: 40 }}>Falcı Paneli - Yayına hazır!</div>;
}